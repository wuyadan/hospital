package crt.factory;

import mysql.crt.com.DBMysql;

public class Factory {
	public static DBMysql getInstanceDB(){
		return new DBMysql();
	}
}

//getInstance是使用单例模式创建类的实例